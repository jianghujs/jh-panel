export function isoNow() {
  return new Date().toISOString();
}
