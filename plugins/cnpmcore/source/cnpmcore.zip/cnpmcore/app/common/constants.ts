export const BUG_VERSIONS = 'bug-versions';
export const LATEST_TAG = 'latest';
