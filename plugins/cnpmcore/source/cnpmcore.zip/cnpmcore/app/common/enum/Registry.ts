export enum RegistryType {
  Npm = 'npm',
  Cnpmcore = 'cnpmcore',
  Cnpmjsorg = 'cnpmjsorg',
}
