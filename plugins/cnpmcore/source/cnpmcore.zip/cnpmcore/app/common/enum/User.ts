export enum LoginResultCode {
  UserNotFound,
  Success,
  Fail,
}
