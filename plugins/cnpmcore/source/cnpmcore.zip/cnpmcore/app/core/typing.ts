import { ChangesStreamService } from './service/ChangesStreamService';

export interface ContextCnpmcore {
  changesStreamService: ChangesStreamService;
}
