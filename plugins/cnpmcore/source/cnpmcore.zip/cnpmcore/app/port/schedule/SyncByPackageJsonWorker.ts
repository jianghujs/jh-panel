import { EggAppConfig, EggLogger } from 'egg';
import { CronParams, Schedule, ScheduleType } from '@eggjs/tegg/schedule';
import { Inject } from '@eggjs/tegg';
import { PackageSyncerService } from '../../core/service/PackageSyncerService';
import { readdir, readFile } from 'fs/promises';
import path from 'path';
// import { PackageRepository } from '../../repository/PackageRepository';
// import { getScopeAndName } from '../../common/PackageUtil';

@Schedule<CronParams>({
  type: ScheduleType.WORKER,
  scheduleData: {
    cron: '0 1 * * *', // run every day at 02:00
  },
}, {
  immediate: true,
})
export class SyncPackageWorker {
  @Inject()
  private readonly packageSyncerService: PackageSyncerService;

  @Inject()
  private readonly config: EggAppConfig;

  @Inject()
  private readonly logger: EggLogger;

  async subscribe() {
    this.logger.info('[SyncByPackageJsonWorker] start execute');
    if (this.config.cnpmcore.syncMode !== 'exist') return;
    const base_path = this.config.package_json_path;
    if (!base_path) {
      this.logger.error('package_json_path is required');
    }
    let files = await readdir(base_path);
    files = files.filter(item => item.endsWith('.json'));
    let dependencies:string[] = [];
    for (const file_name of files) {
      const file_path = path.join(base_path, file_name);
      try {
        const file_str = await readFile(file_path, 'utf-8');
        const packageJson = JSON.parse(file_str.toString());
        if (packageJson.dependencies) {
          const keys = Object.keys(packageJson.dependencies);
          dependencies = dependencies.concat(keys);
        }
      } catch (err) {
        this.logger.error(`Parse json file: ${file_name} error: ${err.message}`);
      }
    }
    dependencies = Array.from(new Set(dependencies));
    // check dependencies
    // const [ scope, name ] = getScopeAndName(params.fullname);
    // const packageEntity = await this.packageRepository.findPackage(scope, name);
    this.logger.info('start execute with dependencies: ', dependencies);
    for (const fullname of dependencies) {
      await this.packageSyncerService.createTask(fullname, {
        authorIp: 'localhost',
        tips: 'SyncByPackageJsonWork',
        skipDependencies: false,
        syncDownloadData: false,
        forceSyncHistory: false,
      });
    }
  }
}
